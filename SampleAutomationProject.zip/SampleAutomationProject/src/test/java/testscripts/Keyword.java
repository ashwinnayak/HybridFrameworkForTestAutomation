package testscripts;

import java.io.IOException;
import java.sql.SQLException;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import testcases.AppTests;

public class Keyword {
    public static String methodReturnResult = null;

    /*****************************
     * DischargeComplete
     * 
     * @throws WriteException
     * @throws RowsExceededException
     * @throws SQLException
     * @throws ParseException
     * @throws FindFailed
     *****************************************/

    // Navigate to the web site of the test app and verify presence of elements
    public static String testKeyword() throws BiffException, InterruptedException, IOException, RowsExceededException,
	    WriteException, SQLException {
	return AppTests.testKeyword();

    }
}
