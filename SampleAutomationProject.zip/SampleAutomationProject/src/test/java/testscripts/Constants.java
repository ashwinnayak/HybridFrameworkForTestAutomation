/*
 * Constants.java contains all the constants need for the test  
 */

package testscripts;

public class Constants {

    public static final String EXPECTEDEDDALERTMESSAGE = "This date is in the past. Is this correct?";
    public static final String EXPECTEDERRORMESSAGE = "Please enter message here.";
    public static final String LOGOUTMESSAGE = "You are now logged out.";
    public static final String EXPECTED_FORM_ALERT_MESSAGE = "You have opened a form. Before you leave this screen, you must save and close the form.";

}
