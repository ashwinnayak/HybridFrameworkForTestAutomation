package testcases;

import java.io.IOException;
import java.sql.SQLException;

import org.openqa.selenium.By;

import testscripts.AppLibrary;
import testscripts.DriverScript;
import testscripts.FunctionLibrary;

//All Hail Automation !

public class AppTests extends DriverScript {
    /*
     * Name of the WebElements present on the WebPage
     */
    public static String nameUserNameInputBox = "'Username' Input-box";
    public static String namePasswordInputBox = "'Password' Input-box";
    public static String nameLogInButton = "'SignIn' Button";
    public static String nameLogOutLink = "'Log Out' link";

    /* .............. Locators for the test ................. */
    public static By locatorUserNameInputBox = By.xpath("");
    public static By locatorPasswordInputBox = By.xpath("");
    public static By locatorLogInButton = By.xpath("");
    public static By locatorLogOutLink = By.xpath("");

    // Navigate to the App and verify presence of elements
    public static String testKeyword() throws SQLException, InterruptedException, IOException {

	APPLICATION_LOGS.debug("Executing test case : ...");

	// Navigate to the App
	methodReturnResult = AppLibrary.navigateToAppWebsite();
	if (methodReturnResult.contains(failTest)) {
	    return methodReturnResult;
	}

	// Verify whether Username input-box, Password input-box and SignIn button
	// present on the page or not
	Boolean usernameFieldPresent = FunctionLibrary.isElementPresent(locatorUserNameInputBox, nameUserNameInputBox);
	Boolean passwdFieldPresent = FunctionLibrary.isElementPresent(locatorPasswordInputBox, namePasswordInputBox);
	Boolean signInButtonPresent = FunctionLibrary.isElementPresent(locatorLogInButton, nameLogInButton);

	// Close Driver
	FunctionLibrary.closeDriver();

	if (!usernameFieldPresent && !passwdFieldPresent && !signInButtonPresent) {
	    return "Fail : Username Field or Password Field or SignIn button is not present on the page ";
	}

	return "Pass: All elements are present in the Login Page";

    }

}